package com.example.latihanrecyclerview

data class MyContact (val nim : String, val nama : String, val nomorTelepon : String,val foto:String)